//
//  main.m
//  Address
//
//  Created by Tuan Nguyen on 9/16/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "LocationAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([LocationAppDelegate class]));
    }
}
