//
//  LocationAppDelegate.h
//  Address
//
//  Created by Tuan Nguyen on 9/16/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LocationAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
