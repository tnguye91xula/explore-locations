//
//  LocationViewController.m
//  Address
//
//  Created by Tuan Nguyen on 9/16/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "LocationViewController.h"
#import <MapKit/MapKit.h>

@interface LocationViewController () <CLLocationManagerDelegate, MKMapViewDelegate, UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UILabel *latitude;
@property (weak, nonatomic) IBOutlet UILabel *longitude;
@property (weak, nonatomic) IBOutlet UILabel *address;
- (IBAction)buttonPressed:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *button;
@property (weak, nonatomic) IBOutlet UITextField *addLatitude;
@property (weak, nonatomic) IBOutlet UITextField *addLongitude;

@end

@implementation LocationViewController
{
    CLPlacemark *placeMark;
    
    float templatitude;
    float templongitude;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    self.addLatitude.placeholder = @"Add Into Latitude";
    [self.addLatitude setDelegate:self];
    
    self.addLongitude.placeholder = @"Add Into Longitude";
    [self.addLongitude setDelegate:self];
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(IBAction)buttonPressed:(id)sender {
    
    
    if([[self.button titleForState:UIControlStateNormal] isEqualToString:@"Where Am I ?"]){
        [self.button setTitle:@"Hide Me!" forState:UIControlStateNormal];
        [self.mapView setDelegate: self];
        [self.mapView setShowsUserLocation:YES];
        [self.view addSubview:self.mapView];
        
    }else{
        [self.button setTitle:@"Where Am I ?" forState:UIControlStateNormal];
        [self.mapView setShowsUserLocation:NO];
        [self.latitude setText:nil];
        [self.longitude setText:nil];
        [self.address setText:nil];
        [self.addLatitude setText:nil];
        [self.addLongitude setText:nil];
        [self.addLatitude setPlaceholder:@"Add Into Latitude"];
        [self.addLongitude setPlaceholder:@"Add Into Longitude"];
    }
}



-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    
    templatitude = userLocation.coordinate.latitude + [self.addLatitude.text floatValue];
    templongitude = userLocation.coordinate.longitude + [self.addLongitude.text floatValue];
    
    CLLocation *currentLocation = [[ CLLocation alloc] initWithLatitude:templatitude longitude:templongitude];
    
    [self.latitude setText:[NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude]];
    [self.longitude setText:[NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude]];
    
    CLGeocoder *geoCoder = [[CLGeocoder alloc] init];
    [geoCoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        
        if (error == nil && [placemarks count] > 0) {
            
            placeMark = [placemarks lastObject];
            
            [self.address setText:[NSString stringWithFormat:@"%@ %@\n%@ %@\n%@\n%@",
                                   placeMark.subThoroughfare, placeMark.thoroughfare,
                                   placeMark.postalCode, placeMark.locality,
                                   placeMark.administrativeArea,
                                   placeMark.country]];
            
        }
        
    } ];
    
    
    [self.mapView setRegion:MKCoordinateRegionMake(currentLocation.coordinate, MKCoordinateSpanMake(0.005f, 0.005f))animated: YES];
}

@end
