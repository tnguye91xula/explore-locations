//
//  LocationViewController.m
//  Address
//
//  Created by Tuan Nguyen on 9/16/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "LocationViewController.h"
#import <MapKit/MapKit.h>

@interface LocationViewController () <CLLocationManagerDelegate, MKMapViewDelegate>
@property (strong, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UILabel *latitude;
@property (weak, nonatomic) IBOutlet UILabel *longitude;
@property (weak, nonatomic) IBOutlet UILabel *address;
- (IBAction)buttonPressed:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *button;


@end

@implementation LocationViewController
{
    CLLocationManager *locationManager;
    CLGeocoder *geoCoder;
    CLPlacemark *placeMark;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    locationManager = [[CLLocationManager alloc] init];
    geoCoder = [[CLGeocoder alloc] init];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



-(IBAction)buttonPressed:(id)sender {
    if([[self.button titleForState:UIControlStateNormal] isEqualToString:@"Where Am I ?"]){
        [self.button setTitle:@"Hide Me!" forState:UIControlStateNormal];
        [self.mapView setDelegate: self];
        [self.mapView setShowsUserLocation:YES];
        [self.view addSubview:self.mapView];
        
        [locationManager setDelegate: self];
        [locationManager setDesiredAccuracy: kCLLocationAccuracyBest];
        [locationManager startUpdatingLocation];
        
    }else{
        [self.button setTitle:@"Where Am I ?" forState:UIControlStateNormal];
        [self.mapView setShowsUserLocation:NO];
        
    }
}

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation
{
    [self.mapView setRegion:MKCoordinateRegionMake(userLocation.coordinate, MKCoordinateSpanMake(0.002f, 0.002f)) animated: YES];
}


-(void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation{
    
    CLLocation *currentLocation = newLocation;
    
    if(currentLocation != nil){
        [self.latitude setText:[NSString stringWithFormat:@"%.8f", currentLocation.coordinate.latitude]];
        [self.longitude setText:[NSString stringWithFormat:@"%.8f", currentLocation.coordinate.longitude]];
    }
    
    if ([[self.button titleForState:UIControlStateNormal] isEqualToString:@"Where Am I ?" ]) {
        [self.latitude setText:nil];
        [self.longitude setText:nil];
    }
    
    [geoCoder reverseGeocodeLocation:currentLocation completionHandler:^(NSArray *placemarks, NSError *error) {
        
        if (error == nil && [placemarks count] > 0) {
            
            placeMark = [placemarks lastObject];
            
            [self.address setText:[NSString stringWithFormat:@"%@ %@\n%@ %@\n%@\n%@",
                                   placeMark.subThoroughfare, placeMark.thoroughfare,
                                   placeMark.postalCode, placeMark.locality,
                                   placeMark.administrativeArea,
                                   placeMark.country]];
            
        }
        
        if ([[self.button titleForState:UIControlStateNormal] isEqualToString:@"Where Am I ?" ]) {
            [self.address setText:nil];
        }
        
    } ];
    
}

@end
