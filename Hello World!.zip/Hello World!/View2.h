//
//  View2.h
//  Hello World!
//
//  Created by Tuan Nguyen on 8/19/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface View2 : UIViewController
{
    IBOutlet UILabel *HelloWorldLabel;
    
}

-(IBAction)Button : (id) sender;


@end
