//
//  XYZViewController.m
//  Hello World!
//
//  Created by Tuan Nguyen on 8/19/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "XYZViewController.h"

@interface XYZViewController ()

@end

@implementation XYZViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
