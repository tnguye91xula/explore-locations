//
//  main.m
//  MapKitDemo
//
//  Created by Tuan Nguyen on 9/12/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "MyLocationAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([MyLocationAppDelegate class]));
    }
}
