//
//  MKViewController.m
//  MapKitDemo
//
//  Created by Tuan Nguyen on 9/12/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "MKViewController.h"
#import <MapKit/MapKit.h>

@implementation MKViewController

- (void) viewDidLoad{
    [super viewDidLoad];
    
    self.mapView = [[MKMapView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    [self.mapView setDelegate:self];
    [self.mapView setShowsUserLocation:YES];
    [self.view addSubview:self.mapView];
    
}

-(void)mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    [self.mapView setRegion:MKCoordinateRegionMake(userLocation.coordinate, MKCoordinateSpanMake(0.001f, 0.001f)) animated: YES];
    
}
@end