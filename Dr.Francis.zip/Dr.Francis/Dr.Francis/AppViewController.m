//
//  AppViewController.m
//  Dr.Francis
//
//  Created by Tuan Nguyen on 10/17/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "AppViewController.h"
#import <MapKit/MapKit.h>

@interface AppViewController ()<MKMapViewDelegate, UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UITextField *latitude;
@property (weak, nonatomic) IBOutlet UITextField *longitude;
@property (weak, nonatomic) IBOutlet UIButton *currentLocationButton;


@end

@implementation AppViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.mapView.mapType = MKMapTypeStandard;
    
    self.latitude.placeholder = @"Latitude Box";
    [self.latitude setDelegate:self];
    
    self.longitude.placeholder = @"Longitude Box";
    [self.longitude setDelegate:self];
}
- (IBAction)setMapType:(UISegmentedControl *)sender {
    switch (sender.selectedSegmentIndex) {
        case 0:
            self.mapView.mapType = MKMapTypeStandard;
            break;
        case 1:
            self.mapView.mapType = MKMapTypeSatellite;
            break;
        case 2:
            self.mapView.mapType = MKMapTypeHybrid;
            break;
        default:
            break;
    }
}
- (IBAction)currentLocation:(UIButton *)sender {
    if([[self.currentLocationButton titleForState:UIControlStateNormal] isEqualToString:@"Current Location"]){
        [self.currentLocationButton setTitle:@"Hide Me!" forState:UIControlStateNormal];
        self.mapView.delegate = self;
        self.mapView.showsUserLocation = YES;
        [self.view addSubview:self.mapView];
    }else{
        [self.currentLocationButton setTitle:@"Current Location" forState:UIControlStateNormal];
        [self.mapView setShowsUserLocation:NO];
    }
}

- (IBAction)dropPinButton:(UIButton *)sender {
    MKPointAnnotation *pinAnnotation = [[MKPointAnnotation alloc] init];
    CLLocationCoordinate2D pinCoordinate;
    pinCoordinate.latitude = [self.latitude.text floatValue];
    pinCoordinate.longitude = [self.longitude.text floatValue];
    pinAnnotation.coordinate = pinCoordinate;
    [self.mapView addAnnotation:pinAnnotation];
    //  if((pinCoordinate.latitude == 29.963932) && (pinCoordinate.longitude ==-90.109033)){
    NSLog(@"%f", pinCoordinate.latitude);
    NSLog(@"%f", pinCoordinate.longitude);
    pinAnnotation.title = @"Retirement announcement 9/4/2014";
    [self.mapView setRegion:MKCoordinateRegionMake(pinCoordinate, MKCoordinateSpanMake(0.0001f, 0.0001f))animated: YES];
}

-(void) mapView:(MKMapView *)mapView didUpdateUserLocation:(MKUserLocation *)userLocation{
    CLLocation *currentLocation = [[ CLLocation alloc] initWithLatitude:userLocation.coordinate.latitude longitude:userLocation.coordinate.longitude];
    [self.mapView setRegion:MKCoordinateRegionMake(currentLocation.coordinate, MKCoordinateSpanMake(0.0001f, 0.0001f))animated: YES];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    [textField resignFirstResponder];
    return YES;
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
