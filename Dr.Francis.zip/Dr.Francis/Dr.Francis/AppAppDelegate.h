//
//  AppAppDelegate.h
//  Dr.Francis
//
//  Created by Tuan Nguyen on 10/17/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
