//
//  main.m
//  Dr.Francis
//
//  Created by Tuan Nguyen on 10/17/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppAppDelegate class]));
    }
}
