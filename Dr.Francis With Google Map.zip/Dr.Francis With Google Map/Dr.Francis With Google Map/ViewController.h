//
//  ViewController.h
//  Dr.Francis With Google Map
//
//  Created by Tuan Nguyen on 10/22/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <GoogleMaps/GoogleMaps.h>

@interface ViewController : UIViewController <GMSMapViewDelegate>
@property (weak, nonatomic) IBOutlet GMSMapView *mapView;


@property(copy, nonatomic) NSSet *markers;




@end


