//
//  ViewController.m
//  Dr.Francis With Google Map
//
//  Created by Tuan Nguyen on 10/22/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"Google Maps in iOS";
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:29.963932
                                                            longitude:-90.10933
                                                                 zoom:30
                                                              bearing:30
                                                         viewingAngle:360];
    
    self.mapView = [GMSMapView mapWithFrame:self.view.bounds camera:camera];
    self.mapView.delegate = self;
    
    self.mapView.myLocationEnabled = YES;
    self.mapView.mapType = kGMSTypeNormal;
    self.mapView.settings.compassButton = YES;
    self.mapView.settings.myLocationButton = YES;
    
    [self.mapView setMinZoom:10 maxZoom:18];
    [self.view addSubview:self.mapView];
    
    GMSMarker *marker1 = [[GMSMarker alloc] init];
    marker1.position = CLLocationCoordinate2DMake(29.963932, -90.10933);
    marker1.title = @"Retirement announcement 9/4/2014";
    marker1.appearAnimation = kGMSMarkerAnimationPop;
    marker1.icon = [GMSMarker markerImageWithColor:[UIColor greenColor]];
    marker1.map = self.mapView;
    
    
}
- (void)setupMarkerData {
    GMSMarker *marker1 = [[GMSMarker alloc] init];
    marker1.position = CLLocationCoordinate2DMake(28.5441, -81.37301);
    marker1.map = nil;
    
    GMSMarker *marker2 = [[GMSMarker alloc] init];
    marker2.position = CLLocationCoordinate2DMake(28.53137, -81.36675);
    marker2.map = nil;
    
    self.markers = [NSSet setWithObjects:marker1, marker2, nil];
    
}

- (void)drawMarkers {
    for(GMSMarker *marker in self.markers) {
        if(marker.map == nil) {
            marker.map = self.mapView;
        }
    }
}

-(BOOL)prefersStatusBarHidden {
    return YES;
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    self.mapView.padding = UIEdgeInsetsMake(self.topLayoutGuide.length + 5,
                                            0,
                                            self.bottomLayoutGuide.length + 5,
                                            0);
}

- (void)mapView:(GMSMapView *)mapView didTapInfoWindowOfMarker:(GMSMarker *)marker {
    NSURL *url = [NSURL URLWithString:[NSString stringWithFormat:@"http://www.xula.edu/mediarelations/A_Legacy_of_Service_&_Leadership.php"]];
    if (![[UIApplication sharedApplication] canOpenURL:url]) {
        NSLog(@"Google Maps app is not installed");
    } else {
        [[UIApplication sharedApplication] openURL:url];
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
