//
//  ViewController.m
//  Dr.Francis With Google Map
//
//  Created by Tuan Nguyen on 10/22/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Google Maps in iOS";
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:29.963932
                                                            longitude:-90.10933
                                                                 zoom:18
                                                              bearing:30
                                                         viewingAngle:40];
    
    self.mapView = [GMSMapView mapWithFrame:CGRectZero camera:camera];
    self.mapView.mapType = kGMSTypeNormal;
    self.mapView.myLocationEnabled =YES;
    self.mapView.settings.compassButton = YES;
    self.mapView.settings.myLocationButton = YES;
    self.view = self.mapView;
    
    GMSMarker *marker1 = [[GMSMarker alloc] init];
    marker1.position = CLLocationCoordinate2DMake(29.963932, -90.10933);
    marker1.title = @"Retirement announcement 9/4/2014";
    marker1.appearAnimation = kGMSMarkerAnimationPop;
    marker1.map = self.mapView;
}

/*- (void)mapView:(GMSMapView *)mapView didTapInfoWindowOfMarker:(GMSMarker *)marker {
 [NSURL URLWithString:@"comgooglemaps://"];
 if ([[UIApplication sharedApplication] canOpenURL:
 [NSURL URLWithString:@"comgooglemaps://"]]) {
 [[UIApplication sharedApplication] openURL:
 [NSURL URLWithString:@"comgooglemaps://?center=40.765819,-73.975866&zoom=14&views=traffic"]];
 } else {
 NSLog(@"Can't use comgooglemaps://");
 }
 }*/
/*- (BOOL)mapView:(GMSMapView *)mapView didTapMarker:(GMSMarker *)marker {
 self.activeMarkerCoordinate = marker.position;
 if (mapView.myLocation != nil) {
 NSURLSessionDataTask *directionsTask = {
 NSError *error = nil;
 NSDictionary *json =
 if (!error) {
 ￼self.steps = json[@"routes"][0][@"legs"][0][@"steps"];
 [[NSOperationQueue mainQueue] addOperationWithBlock:^{
 self.directionsButton.alpha = 1.0;
 GMSPath *path =
 [GMSPath pathFromEncodedPath:
 json[@"routes"][0][@"overview_polyline"][@"points"]];
 self.polyline = [GMSPolyline polylineWithPath:path];
 self.polyline.strokeWidth = 7;
 self.polyline.strokeColor = [UIColor greenColor];
 self.polyline.map = self.mapView;
 ￼￼}];
 } }];
 } }*/
/*-(BOOL)mapView:(GMSMapView *)mapView didTapMarker:(GMSMarker *)marker {
 if (self.mapView.myLocation != nil) {
 NSString *urlString = [NSString stringWithFormat:
 @"%@?origin=%f,%f&destination=%f,%f&sensor=true&key=%@",
 @"https://maps.googleapis.com/maps/api/directions/json",
 self.mapView.myLocation.coordinate.latitude,
 self.mapView.myLocation.coordinate.longitude,
 marker.position.latitude,
 marker.position.longitude,
 @"AE26762kdznyk22lsncnuk42lslcn"];
 NSURL *directionsURL = [NSURL URLWithString:urlString];
 NSURLSessionDataTask *directionsTask = [self.markerSession dataTaskWithURL:directionsURL
 completionHandler:^(NSData *data, NSURLResponse *response, NSError *e){
 }];
 }
 }*/

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
