//
//  ViewController.m
//  Dr.Francis With Google Map
//
//  Created by Tuan Nguyen on 10/22/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"Google Maps in iOS";
    self.mapView.myLocationEnabled = YES;
    self.mapView.mapType = kGMSTypeNormal;
    self.mapView.settings.compassButton = YES;
    GMSCameraPosition *camera = [GMSCameraPosition cameraWithLatitude:30.413258
                                                            longitude:-91.180002
                                                                 zoom:40];
    
    self.mapView.camera = camera;
    self.mapView.delegate = self;
  }

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
