//
//  XYZAppDelegate.h
//  ToDoItem
//
//  Created by Tuan Nguyen on 8/20/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface XYZAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
