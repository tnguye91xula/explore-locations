//
//  MyLocationAppDelegate.h
//  MapDemo
//
//  Created by Tuan Nguyen on 9/12/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyLocationAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
