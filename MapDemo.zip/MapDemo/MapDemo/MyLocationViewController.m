//
//  MyLocationViewController.m
//  MapDemo
//
//  Created by Tuan Nguyen on 9/12/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import "MyLocationViewController.h"

@interface MyLocationViewController ()

@end

@implementation MyLocationViewController
@synthesize mapView;
@synthesize findMeButton;

- (IBAction)findMe:(id)sender {
    if([[findMeButton titleForState:UIControlStateNormal] isEqualToString:@"Find Me"]){
        [findMeButton setTitle:@"Hide Me" forState:UIControlStateNormal];
        mapView.showsUserLocation = YES;
    }else{
        [findMeButton setTitle:@"Find Me" forState:UIControlStateNormal];
        mapView.showsUserLocation = NO;
        
    }
}

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end
