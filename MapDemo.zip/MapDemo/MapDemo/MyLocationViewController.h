//
//  MyLocationViewController.h
//  MapDemo
//
//  Created by Tuan Nguyen on 9/12/14.
//  Copyright (c) 2014 Tuan Nguyen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>
@interface MyLocationViewController : UIViewController
@property (weak, nonatomic) IBOutlet MKMapView *mapView;
@property (weak, nonatomic) IBOutlet UIButton *findMeButton;
- (IBAction)findMe:(id)sender;

@end
